package com.example.instaApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InstaAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(InstaAppApplication.class, args);
	}

}
