package repository;

public class RoleRepository {

}
