package repository;

public interface UserRepository {

}
