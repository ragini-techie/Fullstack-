package security.services;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import repository.UserRepository;




public class UserDetailsServiceImpl {

	  @Autowired
	  UserRepository userRepository;
	 
//	  @Override
//	  @Transactional
//	  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//	 
//	    User user = userRepository.findByUsername(username).orElseThrow(
//	        () -> new UsernameNotFoundException("User Not Found with -> username or email : " + username));
//	 
//	    return UserPrinciple.build(user);
//	  }
	
	
}
