package security.jwt;

public class JwtAuthEntryPoint {

}
